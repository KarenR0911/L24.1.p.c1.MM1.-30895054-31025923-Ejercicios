export default class CL_personal {

constructor(n, tp, s){
    this.nombre = n;
    this.tipopersonal = tp;
    this.sueldo = s;
}

set nombre(n){
    this._nombre= n;
}

set tipopersonal(tp){
    this._tipopersonal= tp;
}
set sueldo(s){
    this._sueldo= +s;
}

get nombre(){
    return this._nombre;}

get tipopersonal(){
    return this._tipopersonal;}

get sueldo(){
    return this._sueldo;}

}
