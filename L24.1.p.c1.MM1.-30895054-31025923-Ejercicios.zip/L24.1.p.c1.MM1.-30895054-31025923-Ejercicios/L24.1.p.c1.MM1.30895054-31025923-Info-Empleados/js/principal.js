import CL_personal from "./CL_personal.js";
import CL_todoempresa from "./CL_todoempresa.js";

let per1 = new CL_personal("Juan", "obrero", 100);
let per2 = new CL_personal("Ana", "obrero", 120);
let per3 = new CL_personal("Lin", "administrativo", 200);
let per4 = new CL_personal("Mary", "obrero", 50);
let per5 = new CL_personal("Carlos", "administrativo", 150);

let empresa = new CL_todoempresa();
empresa.procesar(per1);
empresa.procesar(per2);
empresa.procesar(per3); 
empresa.procesar(per4);
empresa.procesar(per5);

let salida = document.getElementById("Salida");

salida.innerHTML += "Monto total pagado a Obreros: " + empresa.devolverAcum_sueldo_O();
salida.innerHTML += "$"
salida.innerHTML += "<br> Promedio pagado a 3 obreros: " + empresa.promObreros();
salida.innerHTML += "$" 
salida.innerHTML += "<br> Monto total pagado a Administrativos: " + empresa.devolverAcum_sueldo_A();
salida.innerHTML += "$"
salida.innerHTML += "<br> Promedio pagado a 2 administrativos: " + empresa.promAdministrativo();
salida.innerHTML += "$"