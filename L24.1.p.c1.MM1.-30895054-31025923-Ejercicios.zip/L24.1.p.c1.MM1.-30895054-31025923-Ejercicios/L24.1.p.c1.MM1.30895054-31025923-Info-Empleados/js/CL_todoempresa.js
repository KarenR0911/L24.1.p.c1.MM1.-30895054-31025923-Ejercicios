

export default class CL_todoempresa {

constructor(){
    this.cont_o = 0;
    this.cont_administrativo=0;
    this.acum_sueldo_O=0.0;
    this.acum_sueldo_A=0.0;
}

procesar(per){
if(per.tipopersonal=="obrero"){
    this.cont_o++;
    this.acum_sueldo_O+=per.sueldo;
}
if(per.tipopersonal=="administrativo"){
    this.cont_administrativo++;
    this.acum_sueldo_A+=per.sueldo;}

}

promObreros(){
    return this.acum_sueldo_O/this.cont_o;
}

promAdministrativo(){
    return this.acum_sueldo_A/this.cont_administrativo;

}

devolverAcum_sueldo_O(){
    return this.acum_sueldo_O;
}
devolverAcum_sueldo_A(){
    return this.acum_sueldo_A;
}

}