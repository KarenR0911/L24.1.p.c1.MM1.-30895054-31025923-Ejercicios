export default class TodoPersona{
    constructor(){
        this.contPersonas=0;
        this.contMayorEdad=0;
    }
    procesarPersona(per){
        this.contPersonas++;
        if(per.edad>=18){
            this.contMayorEdad++;
    } }
    calcPorcentaje(){
        return (this.contMayorEdad/this.contPersonas)*100;
    }
    devolverPersonas(){
        return this.contPersonas;
    }
    devolverPersonasMayor(){
        return this.contMayorEdad;
    }




}