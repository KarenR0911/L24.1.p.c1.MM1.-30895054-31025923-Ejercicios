export default class Personas {
    constructor(nom, ed){
        this.nombre = nom;
        this.edad = ed;
    }
    set nombre(nom){
        this._nombre = nom;
    }
    set edad(ed){
        this._edad = ed;
    }
    get nombre(){
        return this._nombre;
    }
    get edad(){
        return this._edad;
    }
}