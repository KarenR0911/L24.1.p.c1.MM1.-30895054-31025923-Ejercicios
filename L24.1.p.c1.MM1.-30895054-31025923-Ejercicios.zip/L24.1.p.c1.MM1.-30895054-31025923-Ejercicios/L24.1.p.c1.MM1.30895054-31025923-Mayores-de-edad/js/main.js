/*MAYORES DE EDAD 
Sea el nombre y la edad de varias personas. Se necesita un programa que lea estos datos y 
reporte al final el porcentaje de personas que son mayores de edad. 
Se tienen las siguientes personas: Luis (15), Ana (19), José (21), Carmen (17), Rosa (18), 
José (22), María (17), Luz (19), Rafael (23), Liz (15), Marcos (20) y Leo (16) */

import Personas from "./Persona.js";
import TodoPersona from "./TodoPersona.js";

let per1= new Personas('Luis', 15);
let per2= new Personas('Ana', 19);
let per3= new Personas('José', 21);
let per4= new Personas('Carmen', 17);
let per5= new Personas('Rosa', 18);
let per6= new Personas('José', 22);
let per7= new Personas('María', 17);
let per8= new Personas('Luz', 19);
let per9= new Personas('Rafael', 23);
let per10= new Personas('Liz', 15);
let per11= new Personas('Marcos', 20);
let per12= new Personas('Leo', 16);

let todopersona= new TodoPersona();

todopersona.procesarPersona(per1);
todopersona.procesarPersona(per2);
todopersona.procesarPersona(per3);
todopersona.procesarPersona(per4);
todopersona.procesarPersona(per5);
todopersona.procesarPersona(per6);
todopersona.procesarPersona(per7);
todopersona.procesarPersona(per8);
todopersona.procesarPersona(per9);
todopersona.procesarPersona(per10);
todopersona.procesarPersona(per11);
todopersona.procesarPersona(per12);

let salida= document.getElementById("Salida");
salida.innerHTML= `A continuación se mostrarán los resultados:<br><br>`
salida.innerHTML+= `Cantidad de personas: ${todopersona.devolverPersonas()} <br>`
salida.innerHTML+= `Cantidad de personas mayores de edad: ${todopersona.devolverPersonasMayor()} <br>`
salida.innerHTML+= `Porcentaje de personas mayores de edad: ${todopersona.calcPorcentaje().toFixed()}% <br>`