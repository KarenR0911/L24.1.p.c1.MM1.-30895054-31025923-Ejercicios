/*5. RESULTADOS MATERIA 
Sea la información de varios estudiantes: cédula y nota final. Se sabe que los estudiantes 
aprueban con 48Ptos. 
Se desea procesar a varios estudiantes y determinar la siguiente estadística: cantidad de 
aprobados, cantidad de reprobados y nota promedio de la sección. 
Siendo los resultados de un salón de clases los siguientes: cédula(puntos); 888 (60Ptos), 
777 (50Ptos), 999 (40Ptos), 333 (80Ptos), 111 (30Ptos), 333 (90Ptos), 444 (48Ptos) y 
222 (60Ptos)*/

import Estudiante from "./Estudiante.js";
import Seccion from "./Seccion.js";

let est1= new Estudiante(888, 60);
let est2= new Estudiante(777, 50);
let est3= new Estudiante(999, 40);
let est4= new Estudiante(333, 80);
let est5= new Estudiante(111, 30);
let est6= new Estudiante(333, 90);
let est7= new Estudiante(444, 48);
let est8= new Estudiante(222, 60);

let seccion= new Seccion();
seccion.procesarEstudiante(est1);
seccion.procesarEstudiante(est2);
seccion.procesarEstudiante(est3);
seccion.procesarEstudiante(est4);
seccion.procesarEstudiante(est5);
seccion.procesarEstudiante(est6);
seccion.procesarEstudiante(est7);
seccion.procesarEstudiante(est8);

let salida= document.getElementById("Salida")
salida.innerHTML= `A continuación se mostrarán los resultados:<br><br>`
salida.innerHTML+= `Cantidad de aprobados: ${seccion.devolverApr()}<br>`
salida.innerHTML+= `Cantidad de reprobados: ${seccion.devolverRepr()}<br>`
salida.innerHTML+= `Nota promedio de la sección: ${seccion.calcProm()}`
