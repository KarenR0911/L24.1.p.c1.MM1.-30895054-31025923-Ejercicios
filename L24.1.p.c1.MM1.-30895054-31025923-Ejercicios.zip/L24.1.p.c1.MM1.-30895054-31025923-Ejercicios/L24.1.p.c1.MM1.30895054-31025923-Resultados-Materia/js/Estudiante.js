export default class Estudiante{
    constructor(ced, pto){
        this.cedula = ced;
        this.puntos = pto;
    }
    set cedula(ced){
        this._cedula = ced;
    }
    set puntos(pto){
        this._puntos = pto;
    }
    get cedula(){
        return this._cedula;
    }
    get puntos(){
        return this._puntos;
    }
}