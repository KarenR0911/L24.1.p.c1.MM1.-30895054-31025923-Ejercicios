export default class Seccion {
    constructor(){
        this.acumNota=0;
        this.contEstudiante=0;
        this.contApro=0;
        this.contRep=0;
    }
    procesarEstudiante(est){
        this.contEstudiante++;
        this.acumNota+= est.puntos;
        if(est.puntos>=48){
            this.contApro++;
        } else {
            this.contRep++;
        }
    }
    devolverEstudiantes(){
        return this.contEstudiante;
    }
    devolverRepr(){
        return this.contRep;
    }
    devolverApr(){
        return this.contApro;
    }
    calcProm(){
        return this.acumNota/this.contEstudiante;
    }
}