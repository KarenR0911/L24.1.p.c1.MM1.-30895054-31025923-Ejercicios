export default class Articulo{
    constructor(cod, p, v){
        this.codigo= cod;
        this.precio= p;
        this.venta= v;
    }
    set codigo(cod){
        this._codigo= cod;
    }
    set precio(p){
        this._precio= p;
    }
    set venta(v){
        this._venta= v;
    }
    get codigo(){
        return this._codigo;
        }
    get precio(){
         return this._precio;
        }
    get venta(){
         return this._venta;
        }
    calcGanancia(){
        return this._venta - this._precio;
    }
}