/*6. GANANCIA ARTÍCULOS 
Conociendo el código, costo y el precio de venta de los artículos que vende una tienda, se 
desea hacer un procesamiento que determine la ganancia total que tendría la empresa al 
venderlos todos, y también el código del artículo con mayor precio de venta. 
El encargado de la tienda informa que dispone de los siguientes artículos: 888 (costo $10, 
precio venta $15), 777 (costo $20, precio $25), 999 ($15, $25), 333 ($25, $35), 111 ($50, $70), 
333 ($40, $50), 444 ($80, $100) y 222 ($5, $10) */

import Articulo from "./Articulo.js";
import Empresa from "./Empresa.js";

let art1= new Articulo(888, 10, 15);
let art2= new Articulo(777, 20, 25);
let art3= new Articulo(999, 15, 25);
let art4= new Articulo(333, 25, 35);
let art5= new Articulo(111, 50, 70);
let art6= new Articulo(333, 40, 50);
let art7= new Articulo(444, 80, 100);
let art8= new Articulo(222, 5, 10);

let empresa= new Empresa();
empresa.procesarArticulo(art1);
empresa.procesarArticulo(art2);
empresa.procesarArticulo(art3);
empresa.procesarArticulo(art4);
empresa.procesarArticulo(art5);
empresa.procesarArticulo(art6);
empresa.procesarArticulo(art7);
empresa.procesarArticulo(art8);

let salida= document.getElementById("Salida")
salida.innerHTML= "A continuación se mostrarán los resultados:<br><br>"
salida.innerHTML+= `La ganancia total de la empresa es: $${empresa.devolverGanancia()}<br>`
salida.innerHTML+= `El codigo del artículo con mayor precio de venta es ${empresa.devolverCodigo()}`
