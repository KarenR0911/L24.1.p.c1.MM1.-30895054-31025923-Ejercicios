export default class Empresa{
    constructor(){
        this.acumGanancia=0;
        this.auxCodigo=0;
        this.mayorVenta=0;
    }
    procesarArticulo(art){
        this.acumGanancia+= art.calcGanancia();
        if(art.venta>this.mayorVenta){
            this.auxCodigo= art.codigo;
            this.mayorVenta=art.venta;
    }}
    devolverCodigo(){
        return this.auxCodigo;
    }
    devolverGanancia(){
        return this.acumGanancia;
    }

}