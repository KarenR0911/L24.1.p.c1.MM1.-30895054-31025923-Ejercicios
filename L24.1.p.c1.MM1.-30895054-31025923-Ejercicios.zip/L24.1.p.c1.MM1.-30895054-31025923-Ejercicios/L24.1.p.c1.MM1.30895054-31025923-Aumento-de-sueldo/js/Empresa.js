export default class Empresa {
    constructor(){
        this.acumSueldos=0;
    }
    procesarPersonal(per){
        this.acumSueldos+=per.calcAdicional();
    }
    devolverAdicional(){
        return this.acumSueldos;
    }
}